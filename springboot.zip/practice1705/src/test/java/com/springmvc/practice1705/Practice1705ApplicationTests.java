package com.springmvc.practice1705;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Practice1705ApplicationTests {

	@Test
	void contextLoads() {
	}

}
