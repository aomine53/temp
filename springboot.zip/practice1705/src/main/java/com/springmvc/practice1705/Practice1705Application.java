package com.springmvc.practice1705;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Practice1705Application {

	public static void main(String[] args) {
		SpringApplication.run(Practice1705Application.class, args);
	}

}
