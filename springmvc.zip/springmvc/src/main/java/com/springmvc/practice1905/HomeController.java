package com.springmvc.practice1905;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.springmvc.practice1905.models.User;

@Controller
public class HomeController {
	@RequestMapping("/")
	public String home() {
		return "index";
	}
	
	@RequestMapping("add")
	public ModelAndView add(@RequestParam("num1")int n1, @RequestParam("num2")int n2){
		int res = n1 + n2;
		ModelAndView mv = new ModelAndView("calc");
		mv.addObject("num3", res);
		return mv;
	}
	
	@RequestMapping("register")
	public String register() {
		return "register";
	}
	
	@RequestMapping("addUser")
	public String addUser(@RequestParam("uid")int id, @RequestParam("uname")String name, Model m) {
		User u1 = new User();
		u1.setName(name);
		u1.setUserid(id);
		m.addAttribute("user", u1);
		return "calc";
	}
	
	@ModelAttribute
	public void addModels(Model m) {
		m.addAttribute("name", "Digvijay");
	}
}
